# Dashboard login and independent AR authorization

## Current status
Local Unity and companion patches are implemented. No SQL/function/frontend deployment, repository push or membership mutation was performed.

- Dashboard: https://automotive-diy-proje-8ay4.bolt.host/
- Project: dgyevrlscapokpobbujk
- Callback: com.tayo.carrepairar://auth/callback
- Dedicated broker: /functions/v1/ar-session
- Read-only catalog: /api/projects
- Read-only steps: /api/projects/{UUID|headers|ac-recharge|ac}/steps
- Existing charger-api JWT/RLS path is preserved, not disabled.

## Flow and scope
Unity generates random 256-bit verifier/state. Only state and S256 challenge travel to the dashboard. Dashboard stores these non-secret request values in sessionStorage through OAuth redirects (180-second timeout), authenticates with its existing Supabase session, and shows explicit Authorize AR connection followed by Return to AR. The issue endpoint validates the Supabase user and approved workspace membership.

The callback contains a random 256-bit single-use code and matching state, never access/refresh tokens. Unity exchanges the code with its memory-only verifier over pinned HTTPS. SQL atomically deletes the valid grant and creates a hashed opaque AR session. Grants expire after 90 seconds. AR sessions expire after one hour, with no automatic extension; renew by signing in on the dashboard again. Only hashed code/session tokens are persisted. No upstream Supabase access/refresh token is copied or stored by the broker.

Opaque AR tokens authorize only explicitly allowlisted read routes. Every read checks expiration and current membership. Service-role access is server-side only and is used solely after these checks. This is a single shared approved workspace, not a multi-workspace tenant authorization design. Do not add write routes or arbitrary proxy URLs. Local AR sign-out clears data immediately and attempts broker revocation; browser sign-out is independent. Website password changes/browser logout do not automatically revoke independent AR grants; use membership revocation or delete that user's AR sessions administratively if immediate AR revocation is required.

## Local changes
- Unity SupabaseAuthClient: dashboard launch, state/PKCE exchange, expiring independent session, broker-only logout. Existing public method names retained for serialized compatibility; reachable credential methods redirect to dashboard.
- Phone/glasses account controls: native fields/provider buttons hidden; primary control labelled Sign in on dashboard. Account action opens dashboard. Shared services and existing approval-gated Enter AR remain intact.
- CarRepairAPIClient: pinned read-only broker host/path, no redirect forwarding. Serialized scene URL updated. Approval verification flag remains false until real denial tests pass.
- Companion ARReturn.tsx and App.tsx: explicit consent/return flow inside WorkspaceGate.
- Companion ar-session/index.ts, config.toml and 20261111000000_ar_sessions.sql: private grants/session broker. The dedicated function disables gateway JWT verification because it implements JWT issuance checks and custom code/token validation itself. charger-api retains verify_jwt=true.

## Verified locally
- Unity C# edits compiled successfully; offline DashboardLoginChecks passed RFC7636 vector, callback origin/path/fragment/duplicate rejection, wrong-state and malformed-code no-exchange, cancel cleanup, stale callback rejection, session expiry and unsigned-in AR denial.
- Companion npm run typecheck and npm run build passed.
- Android full build succeeded, 0 errors / 356 warnings:
  Builds/Android/CarRepairAR-DashboardLogin-Diagnostic-20261110-155639.apk
  APK bytes: 160112016.
- Generated Unity manifest contains the app callback scheme and XREAL Unity receiver.
- Public Unity key is now configured (readback only, key never logged); approved-backend verification remains false.
- Editor left outside Play Mode. No device install or successful live login is claimed.

## Unverified / rollout prerequisites
Deno is not available on PATH; edge Deno typecheck was not executed. SQL functions/concurrent exchange and rate-limit behavior require a local/staging Supabase database test. Browser warm/cold Android return, device layout/clipping, real membership denial tests and authenticated checklist synchronization remain unverified. Do not enable approved-backend verification based on the local build alone.

Before production rollout obtain separate explicit authorization for target dgyevrlscapokpobbujk, reviewed diffs, Supabase/Bolt deployment access, selected initial approved account and rollback. Do not request passwords/bearer/service-role tokens in chat. Run Deno check and apply reviewed migrations in staging first; confirm the existing approved-workspace migration is present before the AR migration. Do not overwrite historical migrations or seed/delete repair data.

After staging verification: apply reviewed membership/RLS prerequisites if absent with approval; apply AR migration; deploy only the reviewed function plus frontend with correct public project configuration. Do not deploy a stale frontend build lacking configured VITE variables. Supabase Google/email redirects return to the deployed dashboard origin, not the custom AR callback; the broker constructs the fixed app callback separately.

Required negative tests: missing/invalid JWT issuance, unapproved user, wrong verifier, expired/replayed code, concurrent exchange (at most one success), wrong/expired opaque token, membership revocation, arbitrary read/write route denial, direct client access to private grant/session tables. Ensure no token/code logs. Test logout independently in each client. Set Unity approval verification only after these pass, rebuild, then install on confirmed authorized Beam hardware without clearing app data and launch from My Glasses.

## Rollback
Keep existing native/build repairs and preserve the previous working APK. Restore only scoped local UI/auth/companion changes if needed. For cloud rollback, disable the dedicated broker first, revoke/delete its short-lived grants/sessions, restore the previously reviewed dashboard build, and retain restrictive workspace policies. Do not restore public access or delete user accounts/repair records. New AR tables/functions can be dropped after revocation under explicit authorization; existing membership schema remains untouched.
