-- Local deployment patch only. No Supabase access/refresh tokens are stored.
begin;
create table public.repair_ar_grants (
 code_hash text primary key check (length(code_hash)=64),
 user_id uuid not null references auth.users(id) on delete cascade,
 challenge text not null check (length(challenge)=43),
 expires_at timestamptz not null default now()+interval '90 seconds',
 created_at timestamptz not null default now()
);
create table public.repair_ar_sessions (
 token_hash text primary key check (length(token_hash)=64),
 user_id uuid not null references auth.users(id) on delete cascade,
 expires_at timestamptz not null,
 created_at timestamptz not null default now()
);
alter table public.repair_ar_grants enable row level security;
alter table public.repair_ar_sessions enable row level security;
revoke all on public.repair_ar_grants, public.repair_ar_sessions from public, anon, authenticated;
grant select,insert,delete on public.repair_ar_grants, public.repair_ar_sessions to service_role;

create function public.repair_ar_exchange(p_code_hash text,p_challenge text,p_token_hash text)
returns table(user_id uuid,expires_at timestamptz)
language plpgsql security definer set search_path=pg_catalog,public
as $$
declare g public.repair_ar_grants%rowtype;
begin
 delete from public.repair_ar_grants r
 where r.code_hash=p_code_hash and r.challenge=p_challenge and r.expires_at>now()
 returning r.* into g;
 if not found then return; end if;
 if not exists(select 1 from public.repair_workspace_members m where m.user_id=g.user_id and m.approved=true) then return; end if;
 return query insert into public.repair_ar_sessions(token_hash,user_id,expires_at)
 values(p_token_hash,g.user_id,now()+interval '1 hour')
 returning repair_ar_sessions.user_id,repair_ar_sessions.expires_at;
end;
$$;
revoke all on function public.repair_ar_exchange(text,text,text) from public,anon,authenticated;
grant execute on function public.repair_ar_exchange(text,text,text) to service_role;

-- Atomic per-user issuance limit: at most five grants in a rolling minute.
create function public.repair_ar_issue(p_user uuid,p_code_hash text,p_challenge text)
returns boolean language plpgsql security definer set search_path=pg_catalog,public
as $$
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if not exists(select 1 from public.repair_workspace_members m where m.user_id=p_user and m.approved=true) then return false; end if;
 if (select count(*) from public.repair_ar_grants g where g.user_id=p_user and g.created_at>now()-interval '1 minute')>=5 then return false; end if;
 delete from public.repair_ar_grants where expires_at<=now();
 delete from public.repair_ar_sessions where expires_at<=now();
 insert into public.repair_ar_grants(code_hash,user_id,challenge) values(p_code_hash,p_user,p_challenge);
 return true;
end;
$$;
revoke all on function public.repair_ar_issue(uuid,text,text) from public,anon,authenticated;
grant execute on function public.repair_ar_issue(uuid,text,text) to service_role;
commit;
