-- REVIEW AND DEPLOY ONLY AFTER EXPLICIT PRODUCTION APPROVAL.
-- One shared vehicle workspace; signup does not create an approved membership.
-- Existing vehicle/project/step records and IDs are not changed.
BEGIN;

CREATE TABLE IF NOT EXISTS public.repair_workspace_members (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  approved boolean NOT NULL DEFAULT false,
  approved_at timestamptz
);
ALTER TABLE public.repair_workspace_members ENABLE ROW LEVEL SECURITY;
DO $membership_check$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_catalog.pg_policies
    WHERE schemaname = 'public' AND tablename = 'repair_workspace_members'
    AND policyname <> 'read_own_repair_membership') THEN
    RAISE EXCEPTION 'Unexpected workspace membership policy; review deployed state before applying changes';
  END IF;
END;
$membership_check$;
REVOKE ALL ON TABLE public.repair_workspace_members FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.repair_workspace_members TO authenticated;
DROP POLICY IF EXISTS "read_own_repair_membership" ON public.repair_workspace_members;
CREATE POLICY "read_own_repair_membership" ON public.repair_workspace_members
  FOR SELECT TO authenticated USING (user_id = (SELECT auth.uid()));

CREATE OR REPLACE FUNCTION public.is_repair_workspace_approved()
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = ''
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.repair_workspace_members AS m
    WHERE m.user_id = (SELECT auth.uid()) AND m.approved = true
  );
$function$;
REVOKE ALL ON FUNCTION public.is_repair_workspace_approved() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_repair_workspace_approved() TO authenticated;

DO $migration$
DECLARE
  item record;
  verb text;
  recognized text[];
BEGIN
  FOR item IN SELECT * FROM (VALUES
    ('vehicle_profile', 'vehicle'),
    ('maintenance_logs', 'mlogs'),
    ('active_upgrades', 'upgrades'),
    ('upcoming_services', 'upcoming'),
    ('projects', 'projects'),
    ('project_steps', 'steps'),
    ('parts_inventory', 'parts'),
    ('tools_checklist', 'tools'),
    ('media_tutorials', 'media')
  ) AS targets(table_name, policy_suffix)
  LOOP
    IF to_regclass(format('public.%I', item.table_name)) IS NULL THEN
      RAISE EXCEPTION 'Expected repair table % is missing; no migration applied', item.table_name;
    END IF;
    recognized := ARRAY[
      'anon_select_' || item.policy_suffix,
      'anon_insert_' || item.policy_suffix,
      'anon_update_' || item.policy_suffix,
      'anon_delete_' || item.policy_suffix,
      'approved_workspace_access'];
    IF EXISTS (SELECT 1 FROM pg_catalog.pg_policies
      WHERE schemaname = 'public' AND tablename = item.table_name
      AND NOT (policyname::text = ANY(recognized))) THEN
      RAISE EXCEPTION 'Unexpected policy on %; review deployed state before applying security changes', item.table_name;
    END IF;
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', item.table_name);
    EXECUTE format('REVOKE ALL ON TABLE public.%I FROM PUBLIC, anon', item.table_name);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.%I TO authenticated', item.table_name);
    FOREACH verb IN ARRAY ARRAY['select', 'insert', 'update', 'delete']
    LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', 'anon_' || verb || '_' || item.policy_suffix, item.table_name);
    END LOOP;
    EXECUTE format('DROP POLICY IF EXISTS approved_workspace_access ON public.%I', item.table_name);
    EXECUTE format('CREATE POLICY approved_workspace_access ON public.%I FOR ALL TO authenticated USING (public.is_repair_workspace_approved()) WITH CHECK (public.is_repair_workspace_approved())', item.table_name);
  END LOOP;
END;
$migration$;

COMMENT ON TABLE public.repair_workspace_members IS 'Administrator-managed approval for the shared repair workspace. Clients may read only their own approval, never insert/update/delete it.';
COMMIT;
